from serpapi import GoogleSearch

params = {
    "q": "Python programming",
    "api_key": "175c4952dd5ed54c366f57c1e1a52b489cdfed7f485d3e3fc56607c663f4ef01"
}

search = GoogleSearch(params)
results = search.get_dict()
print(results['organic_results'][0]['title'])
